![Django + Charts.js Logo](https://cfe2-static.s3-us-west-2.amazonaws.com/media/projects/django-chartjs/images/share/django_plus_charts_js_share.png)

# Django + Charts.js
Learn how to integrate Charts.js with Django.

We show you how to integrate:
[Chart.js](http://www.chartjs.org/) with [Django](http://django.project.com) and the [Django Rest Framework](http://www.django-rest-framework.org/)

What to see more Chart.js? Submit & Upvote [here](http://joincfe.com/suggest/)

Subscribe to our YouTube channel: [http://joincfe.com/youtube/](http://joincfe.com/youtube/)


### Code History
[Base project setup](../../tree/9deb1d489250aca706b9939ae0bad331d0709982)

[Django + Chart.js end](../../tree/acd0853295ef60abb5aa72e8397d405746885d30)